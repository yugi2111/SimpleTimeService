import json
import datetime

def lambda_handler(event, context):
    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps({
            "timestamp": datetime.datetime.utcnow().isoformat(),
            "ip": event["requestContext"]["identity"]["sourceIp"]
        })
    }
